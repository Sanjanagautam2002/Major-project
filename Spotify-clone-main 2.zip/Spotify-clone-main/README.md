# Spotify-clone
In this project we tried to create a clone of spotify with some songs but since some fonts and parts of projects are taken online , thus this webpage will work only when we are online.

![Home page](https://user-images.githubusercontent.com/61690911/183033827-eda659a8-8009-48ab-a61d-e03e88b42d35.PNG)
![about](https://user-images.githubusercontent.com/61690911/183033836-220bced3-3f4d-4474-aeac-4a0c91e70bd8.PNG)
